zbiór chyba wszystkich algorytmów poruszanych na ASD, klasycznie bez gwarancji poprawności, ale wszystko wydaje się działać

Używałem plików nagłówkowych - jeżeli nie wiesz o co z nimi chodzi, to możesz po prostu przekopiować ich zawartość do odpowiednich .cpp

W sortowaniach tablic operowałem na klasie - jeżeli tego nie znasz, to możesz na żywca przekopiować sobie funkcje sortujące z pliku .cpp do swojego maina - pamiętaj tylko o uzupełnieniu deklaracji tych funkcji o rozmiar i tablicę