from zad1testy import runtests

def Median(T):
    # tu prosze wpisac wlasna implementacje
    return

runtests( Median ) 
