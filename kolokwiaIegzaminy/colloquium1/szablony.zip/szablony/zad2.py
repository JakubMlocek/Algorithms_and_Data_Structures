from zad2testy import runtests

class Node:
  def __init__(self):
    self.val = None     
    self.next = None 



def SortH(p,k):
    # tu prosze wpisac wlasna implementacje
    pass


runtests( SortH ) 