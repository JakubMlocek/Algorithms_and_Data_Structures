from zad1testy import runtests


def tanagram(x, y, t):
    # tu prosze wpisac wlasna implementacje
    return None


runtests( tanagram )