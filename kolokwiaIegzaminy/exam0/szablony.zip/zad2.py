from zad2testy import runtests

class Node:
  def __init__( self ):
    self.left    = None  # lewe podrzewo
    self.leftval = 0     # wartość krawędzi do lewego poddrzewa jeśli istnieje
    self.right   = None  # prawe poddrzewo
    self.rightval= 0     # wartość krawędzi do prawego poddrzewa jeśli istnieje
    self.X       = None  # miejsce na dodatkowe dane

def valuableTree( T, k ):
    """tu prosze wpisac wlasna implementacje"""
    return 0

    
runtests( valuableTree )


