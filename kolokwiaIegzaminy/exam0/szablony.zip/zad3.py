from zad3testy import runtests


def jumper(G, s, w):
    raise NotImplementedError


runtests(jumper)